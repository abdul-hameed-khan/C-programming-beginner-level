#include <stdio.h>
#include <stdlib.h>

int main()
{
	int dec, deci;
	int d1,d2,d3,d4;
	
	printf("Enter a decimal number (1 ... 15) : ");
	scanf("%d",&dec);
	
	deci = dec;
	d1 = dec % 2;
	
	dec = dec / 2;
	d2 = dec % 2;
	
	dec = dec / 2;
	d3 = dec % 2;
	
	dec = dec / 2;
	d4 = dec % 2;
	
	printf("The binary of %d is %d%d%d%d\n",deci,d4,d3,d2,d1);
	
	system("pause");
	return 0;
}
