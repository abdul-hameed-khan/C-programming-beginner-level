#include <stdio.h>
#include <stdlib.h>

int main()
{
	int bin;
	int b1, b2, b3, b4;
	int deci;
	
	printf("Enter a 4 bit binary number : ");
	scanf("%d",&bin);
	
	
	b1 = bin % 2;
	
	b2 = bin/10 % 2;
	
	b3 = bin/100 % 2;
	
	b4 = bin/1000 % 2;
	
	deci = b1 * 1 + b2 * 2 + b3 * 4 + b4 * 8;
	
	printf("The decimal of %d is %d\n",bin,deci);
	
	system("pause");
	return 0;
}
