#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
	int num1, num2;
	int res;
	float resf;
	
	printf("Enter two integers\n");
	printf("1st Number: ");
	scanf("%d",&num1);
	printf("2nd Number: ");
	scanf("%d",&num2);
	
	printf("Is %d == %d : ",num1, num2);
	num1==num2 ? printf("Yes\n"): printf("No\n");
	printf("Is %d > %d : ",num1, num2);
	num1>num2 ? printf("Yes\n"): printf("No\n");
	printf("Is %d < %d : ",num1, num2);
	num1<num2 ? printf("Yes\n"): printf("No\n");
	printf("Is %d between 1 ... 10 : ",num1);
	num1>=1 && num1<=10 ? printf("Yes\n"): printf("No\n");
	printf("Is %d between 1 ... 10 : ",num2);
	num2>=1 && num2<=10 ? printf("Yes\n"): printf("No\n");
	num1>num2 ? res = num1-num2: res = num1+num2;
	num1>num2 ? printf("As %d > %d we will subtract them %d - %d = %d\n",num1,num2,num1,num2,res): 
				printf("As %d <= %d we will add them %d + %d = %d\n",num1,num2,num1,num2,res);
	(num1>=1 && num1<=10) && (num2>=1 && num2<=10)? resf = pow(num1,num2) : resf = sqrt(num1)-sqrt(num2);
	(num1>=1 && num1<=10) && (num2>=1 && num2<=10)? 
				printf("As %d and %d are between 1 .... 10 we will perform  pow(%d,%d) = %f\n",num1,num2,num1,num2,resf): 
				printf("As one of %d or %d is not between 1 .... 10 we will perform sqrt(%d)-sqrt(%d) = %f\n",num1,num2,num1,num2,resf);
	 
	system("pause");
	return 0;
}
